#!/bin/bash
# ==============================================
# Compte Rendu - Docker Entrypoint (Supabase PostgreSQL)
# Handles database initialization with Supabase
# ==============================================

set -e

echo "🚀 Compte Rendu démarrage..."

# Ensure upload directory exists
mkdir -p /app/public/upload

# Initialize/Update database schema if DATABASE_URL is set (Supabase)
if [ -n "$DATABASE_URL" ]; then
    echo "📊 Synchronisation du schéma avec Supabase..."
    cd /app
    bunx prisma db push --accept-data-loss 2>/dev/null || echo "⚠️ Schéma déjà à jour ou erreur mineure"
    echo "✅ Base de données prête"
else
    echo "⚠️ DATABASE_URL non définie - certaines fonctionnalités ne fonctionneront pas"
fi

# Start the application
echo "🌐 Démarrage du serveur sur le port ${PORT:-3000}..."
exec "$@"
